<?php
$_['heading_title'] = 'WorldLinePay';
 
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
 
$_['text_config_one'] = 'Parameter one';
$_['text_config_two'] = 'Parameter Two';
 
$_['entry_status'] = 'Status:';
$_['entry_order_status'] = 'Order Status:';
 
$_['text_button_save'] = 'Save';
$_['text_button_cancel'] = 'Cancel';
?>